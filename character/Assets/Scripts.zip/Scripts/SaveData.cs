using UnityEngine;

[System.Serializable]
public class SaveData
{
    public Vector3 playerPosition;
}
